-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Oct 14, 2023 at 04:15 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task_today`
--

-- --------------------------------------------------------

--
-- Table structure for table `product_carts`
--

CREATE TABLE `product_carts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_carts`
--

INSERT INTO `product_carts` (`id`, `user_id`, `product_id`, `updated_at`, `created_at`) VALUES
(1, 3, 3, '2023-10-14 13:09:19', '2023-10-14 13:09:19'),
(2, 3, 1, '2023-10-14 13:09:57', '2023-10-14 13:09:57'),
(4, 3, 1, '2023-10-14 13:45:07', '2023-10-14 13:45:07'),
(5, 3, 2, '2023-10-14 13:45:09', '2023-10-14 13:45:09'),
(6, 3, 3, '2023-10-14 13:45:12', '2023-10-14 13:45:12'),
(7, 4, 1, '2023-10-14 14:14:03', '2023-10-14 14:14:03');

-- --------------------------------------------------------

--
-- Table structure for table `product_details`
--

CREATE TABLE `product_details` (
  `id` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_details`
--

INSERT INTO `product_details` (`id`, `product_name`, `product_price`, `quantity`) VALUES
(1, 'Laptop 1', 50000, 5),
(2, 'Laptop 2', 57000, 5),
(3, 'Laptop 3', 7000, 5),
(4, 'Laptop 4', 75800, 56);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `updated_at` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `password`, `updated_at`, `created_at`) VALUES
(1, '2', '2', '$2y$10$TEPuFTcUvK4hjZsCxhXj/.SDT8g5ppUI/hW2f4B2Iurpo7W389w4u', '2023-10-14 11:20:31', '2023-10-14 11:20:31'),
(2, '2', '2', '$2y$10$oogB/RCVhi/Vn/PWXq.E3.Z6zVhkvfnyR4EmipQhz.V4ropa.x2EC', '2023-10-14 11:20:58', '2023-10-14 11:20:58'),
(3, '3', '3', '$2y$10$.sijEt.kKRxn18aGugX/uuzV6kj3ouvmcqd7dZz9s1gfjUD5WxMpG', '2023-10-14 12:41:56', '2023-10-14 12:41:56'),
(4, 'mk', '9709787061', '$2y$10$FeFekiveqMoJ2HKr5zCQneVPqUUwQHcALOOsmcKsQTVB0Me78.89i', '2023-10-14 14:13:29', '2023-10-14 14:13:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product_carts`
--
ALTER TABLE `product_carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_details`
--
ALTER TABLE `product_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product_carts`
--
ALTER TABLE `product_carts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `product_details`
--
ALTER TABLE `product_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
