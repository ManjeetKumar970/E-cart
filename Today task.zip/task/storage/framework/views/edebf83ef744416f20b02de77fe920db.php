<!DOCTYPE html>
<html lang="en">
<?php

use App\Models\Product_detail;

 $products = Product_detail::all();
?>
<head>
    <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
   
    <main class="cd__main">
        <!-- Start DEMO HTML (Use the following code into your project)-->
        <div class="container-fluid bg-trasparent my-4 p-3" style="position: relative">
            <div class="row row-cols-1 row-cols-xs-2 row-cols-sm-2 row-cols-lg-4 g-3">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col hp">
                        <div class="card h-100 shadow-sm">
                            <a href="#">
                                <img src="https://m.media-amazon.com/images/I/81gK08T6tYL._AC_SL1500_.jpg" class="card-img-top" alt="<?php echo e($prod->product_name); ?>" />
                            </a>

                            <div class="label-top shadow-sm">
                                <a class="text-white" href="#"><?php echo e($prod->id); ?></a>
                            </div>
                            <div class="card-body">
                                <div class="clearfix mb-3">
                                    <span class="float-start badge rounded-pill bg-success"><?php echo e($prod->product_price); ?>$</span>

                                    <span class="float-end"><a href="#" class="small text-muted text-uppercase aff-link">reviews</a></span>
                                </div>
                                <h5 class="card-title">
                                    <a target="_blank" href="#"><?php echo e($prod->product_name); ?></a>
                                </h5>

                                <div class="d-grid gap-2 my-4">
                                <?php if(session('user_id'==null)): ?>
                                    <a href="/login" class="btn btn-warning bold-btn">Add to Cart</a>
                                <?php else: ?>
                                <form action="<?php echo e(route('saveCart')); ?>" method="POST" style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="product_id" value="<?php echo e($prod->id); ?>" id="">
                                            <input type="hidden" name="user_id" value="<?php echo e(session('user_id')); ?>" id="">
                                            <button  class="btn btn-warning bold-btn">Add to Cart</button>
                                        </form>
                               
                             <?php endif; ?>
                            </div>
                                <div class="clearfix mb-1">
                                    <span class="float-start"><a href="#"><i class="fas fa-question-circle"></i></a></span>
                                    <span class="float-end">
                                        <i class="far fa-heart" style="cursor: pointer"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </main>
</body>

</html>
<?php /**PATH F:\Today task\task\resources\views/index.blade.php ENDPATH**/ ?>