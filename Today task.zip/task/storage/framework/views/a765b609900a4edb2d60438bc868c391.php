<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <div class="register-container">
        <h2><?php echo e(session()->has('done')); ?></h2>
        <form class="register-form" action="<?php echo e(route('userLogin')); ?>" method="post">
        <?php echo csrf_field(); ?>
            <h2>Login</h2>
            <label for="username">Username:</label>
            <input type="text" id="username" name="name" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Login</button>
            <a href="reg">Regester</a>
        </form>
    </div>
</body>
</html>
<?php /**PATH F:\Today task\task\resources\views/login.blade.php ENDPATH**/ ?>