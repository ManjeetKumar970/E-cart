<!DOCTYPE html>
<html lang="en">
<head>
    <?php

use App\Models\Product_cart;
use App\Models\Product_detail;
$user=session('user_id');

 $userCart = Product_cart::where('user_id', $user)->get();
     ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
     <div class="container card">
         
     <div class="card-body">

     <?php $__currentLoopData = $userCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
    <?php
    $items = Product_detail::where('id', $product->product_id)->get();
    ?>
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="card">
        <table>
        <tr>
            
            <td>
                <p> PRODUCT NAME :<?php echo e($item->product_name); ?></p>
            </td>
            <td>
                <p>PRICE :<?php echo e($item->product_price); ?></p>
            </td>
            <td>
                <p>AVL PRODUCT :<?php echo e($item->quantity); ?></p>
            </td>
            <td>
                SELECT QTY :<input type="number" name="quantity" id="" >
            </td>
            <td>
            <a href="deletecart/<?php echo e($item->id); ?>/<?php echo e($product->user_id); ?>" class="btn btn-danger">Remove</a>
            </td>
        </tr> 
        </table>
       </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     </div>

     </div>
</body>
</html><?php /**PATH F:\Today task\task\resources\views/cart.blade.php ENDPATH**/ ?>