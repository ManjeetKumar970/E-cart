<?php

namespace App\Http\Controllers;

use App\Models\Product_cart;
use App\Models\product_detail;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Users extends Controller
{
   public function userReg(Request $req){
  
    $user= new User();
    $user->name=$req->username;
    $user->phone=$req->phone;
    $user->password =$req->password;
    $user->save();
   return redirect('reg')->with('done','User Reg');
   }

   public function userLogin(Request $request)
{
    $credentials = $request->only('name', 'password');

    if (Auth::attempt($credentials)) {
  
        $user = Auth::user(); 

      
        session(['user_id' => $user->id]);
        session(['user_name' => $user->name]);

        return redirect()->intended('index'); 
    }

    
    return redirect('reg');
}

public function logout()
{
    Auth::logout(); // Laravel's method to log the user out
    session()->flush(); // Clear all session data

    return redirect('login');
}

public function product_details()
{
    $products = product_detail::all();
    return view('index', ['data' => $products]);
}

public function saveCart(Request $req){
    $product =new Product_cart();
    $product->product_id=$req->product_id;
   $product->user_id =$req ->user_id; 
 
   $product->save();
    return redirect('index');
   
}

public function deletecart($id, $user_id)
{
    Product_cart::where('id', $id)->where('user_id', $user_id)->delete();

    return redirect()->back(); 
}


}
