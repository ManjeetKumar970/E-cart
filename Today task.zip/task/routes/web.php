<?php

use App\Http\Controllers\Users;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::view('index','index');
Route::view('login','login');
Route::post('login', [Users::class, 'userLogin'])->name('userLogin');

Route::view('reg','reg');
Route::post('reg', [Users::class, 'userReg'])->name('userReg');


Route::post('saveCart',[Users::class,'saveCart'])->name('saveCart');

Route::view('cart','cart');

Route::get('deletecart/{id}/{user_id}', [Users::class, 'deletecart'])->name('deletecart');

Route::post('logout', [Users::class, 'logout'])->name('logout');



