<!DOCTYPE html>
<html lang="en">
<head>
    @include('inc.header')
</head>
<body>
    <div class="register-container">
     
        <form class="register-form" action="/reg" method="post">
          @csrf
            <h2>Register</h2>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="phone">Phone:</label>
            <input type="tel" id="phone" name="phone" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Register</button>
        </form>
    </div>
</body>
</html>
