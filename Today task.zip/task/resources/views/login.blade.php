<!DOCTYPE html>
<html lang="en">
<head>
    @include('inc.header')
</head>
<body>
    <div class="register-container">
        <h2>{{session()->has('done')}}</h2>
        <form class="register-form" action="{{ route('userLogin') }}" method="post">
        @csrf
            <h2>Login</h2>
            <label for="username">Username:</label>
            <input type="text" id="username" name="name" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Login</button>
            <a href="reg">Regester</a>
        </form>
    </div>
</body>
</html>
