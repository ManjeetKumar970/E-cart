<!DOCTYPE html>
<html lang="en">
<head>
    <?php

use App\Models\Product_cart;
use App\Models\Product_detail;
$user=session('user_id');

 $userCart = Product_cart::where('user_id', $user)->get();
     ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('inc.header')
</head>
<body>
     <div class="container card">
         
     <div class="card-body">

     @foreach($userCart as $product)
   
    <?php
    $items = Product_detail::where('id', $product->product_id)->get();
    ?>
    @foreach($items as $item)
       <div class="card">
        <table>
        <tr>
            
            <td>
                <p> PRODUCT NAME :{{$item->product_name}}</p>
            </td>
            <td>
                <p>PRICE :{{$item->product_price}}</p>
            </td>
            <td>
                <p>AVL PRODUCT :{{$item->quantity}}</p>
            </td>
            <td>
                SELECT QTY :<input type="number" name="quantity" id="" >
            </td>
            <td>
            <a href="deletecart/{{$item->id}}/{{$product->user_id}}" class="btn btn-danger">Remove</a>
            </td>
        </tr> 
        </table>
       </div>
    @endforeach
@endforeach

     </div>

     </div>
</body>
</html>