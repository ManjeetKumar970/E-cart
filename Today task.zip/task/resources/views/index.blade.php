<!DOCTYPE html>
<html lang="en">
<?php

use App\Models\Product_detail;

 $products = Product_detail::all();
?>
<head>
    @include('inc.header')
</head>

<body>
   
    <main class="cd__main">
        <!-- Start DEMO HTML (Use the following code into your project)-->
        <div class="container-fluid bg-trasparent my-4 p-3" style="position: relative">
            <div class="row row-cols-1 row-cols-xs-2 row-cols-sm-2 row-cols-lg-4 g-3">
                @foreach($products as $prod)
                    <div class="col hp">
                        <div class="card h-100 shadow-sm">
                            <a href="#">
                                <img src="https://m.media-amazon.com/images/I/81gK08T6tYL._AC_SL1500_.jpg" class="card-img-top" alt="{{ $prod->product_name }}" />
                            </a>

                            <div class="label-top shadow-sm">
                                <a class="text-white" href="#">{{ $prod->id }}</a>
                            </div>
                            <div class="card-body">
                                <div class="clearfix mb-3">
                                    <span class="float-start badge rounded-pill bg-success">{{ $prod->product_price }}$</span>

                                    <span class="float-end"><a href="#" class="small text-muted text-uppercase aff-link">reviews</a></span>
                                </div>
                                <h5 class="card-title">
                                    <a target="_blank" href="#">{{ $prod->product_name }}</a>
                                </h5>

                                <div class="d-grid gap-2 my-4">
                                @if(session('user_id'==null))
                                    <a href="/login" class="btn btn-warning bold-btn">Add to Cart</a>
                                @else
                                <form action="{{ route('saveCart') }}" method="POST" style="display: inline;">
                                            @csrf
                                            <input type="hidden" name="product_id" value="{{ $prod->id }}" id="">
                                            <input type="hidden" name="user_id" value="{{session('user_id')}}" id="">
                                            <button  class="btn btn-warning bold-btn">Add to Cart</button>
                                        </form>
                               
                             @endif
                            </div>
                                <div class="clearfix mb-1">
                                    <span class="float-start"><a href="#"><i class="fas fa-question-circle"></i></a></span>
                                    <span class="float-end">
                                        <i class="far fa-heart" style="cursor: pointer"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </main>
</body>

</html>
